// Sample recipes data (can be fetched from a server)
const recipes = [
  {
    title: "Spaghetti Carbonara",
    category: "Italian",
    ingredients: ["spaghetti", "bacon", "eggs", "cheese"],
    preparationSteps: [
      "Step 1: Cook spaghetti",
      "Step 2: Fry bacon",
      "Step 3: Beat eggs and mix with cheese",
      "Step 4: Combine all ingredients",
    ],
  },
  {
    title: "Tacos",
    category: "Mexican",
    ingredients: ["tortillas", "ground beef", "lettuce", "tomatoes", "cheese"],
    preparationSteps: [
      "Step 1: Cook ground beef",
      "Step 2: Prepare taco fillings",
      "Step 3: Assemble tacos",
    ],
  },
  {
    title: "Chicken Curry",
    category: "Indian",
    ingredients: [
      "chicken",
      "onion",
      "tomatoes",
      "garlic",
      "ginger",
      "curry powder",
    ],
    preparationSteps: [
      "Step 1: Cook chicken",
      "Step 2: Fry onions, garlic, and ginger",
      "Step 3: Add tomatoes and curry powder",
      "Step 4: Combine with cooked chicken",
    ],
  },
  {
    title: "Caesar Salad",
    category: "American",
    ingredients: [
      "romaine lettuce",
      "croutons",
      "parmesan cheese",
      "Caesar dressing",
    ],
    preparationSteps: [
      "Step 1: Toss lettuce with dressing",
      "Step 2: Add croutons and cheese",
      "Step 3: Serve chilled",
    ],
  },
  {
    title: "Sushi Rolls",
    category: "Japanese",
    ingredients: [
      "sushi rice",
      "nori seaweed",
      "fish (e.g., tuna, salmon)",
      "avocado",
      "cucumber",
    ],
    preparationSteps: [
      "Step 1: Cook sushi rice",
      "Step 2: Prepare fillings",
      "Step 3: Assemble sushi rolls",
    ],
  },
  // Add more recipes
];

const recipeSection = document.getElementById("recipes");

// Function to display recipes
function displayRecipes(recipes) {
  recipeSection.innerHTML = "";
  recipes.forEach((recipe) => {
    const recipeDiv = document.createElement("div");
    recipeDiv.classList.add("recipe");
    recipeDiv.innerHTML = `
        <h3>${recipe.title}</h3>
        <p><strong>Category:</strong> ${recipe.category}</p>
        <p><strong>Ingredients:</strong> ${recipe.ingredients.join(", ")}</p>
        <p><strong>Preparation:</strong></p>
        <ul>${recipe.preparationSteps
          .map((step) => `<li>${step}</li>`)
          .join("")}</ul>
        <button class="rate-btn">Rate</button>
        <button class="comment-btn">Comment</button>
        <button class="share-btn">Share</button>
      `;
    recipeSection.appendChild(recipeDiv);
  });
}

// Initial display of recipes
displayRecipes(recipes);

// Event listener for search button
document.querySelector("#search button").addEventListener("click", () => {
  const searchTerm = document.querySelector("#search input").value;
  const filteredRecipes = recipes.filter((recipe) =>
    recipe.title.toLowerCase().includes(searchTerm.toLowerCase())
  );
  displayRecipes(filteredRecipes);
});

// Event listener for filter button
document.querySelector("#filters button").addEventListener("click", () => {
  const category = document.querySelector("#category").value;
  const ingredient = document.querySelector("#ingredient").value.toLowerCase();
  let filteredRecipes = recipes;
  if (category !== "all") {
    filteredRecipes = filteredRecipes.filter(
      (recipe) => recipe.category.toLowerCase() === category.toLowerCase()
    );
  }
  if (ingredient) {
    filteredRecipes = filteredRecipes.filter((recipe) =>
      recipe.ingredients.map((ing) => ing.toLowerCase()).includes(ingredient)
    );
  }
  displayRecipes(filteredRecipes);
});

// Event listener for rating button
document.querySelectorAll(".rate-btn").forEach((button) => {
  button.addEventListener("click", (event) => {
    const recipeTitle =
      event.target.parentElement.querySelector("h3").textContent;
    // Here you can implement the logic to handle rating
    alert(`You clicked Rate for ${recipeTitle}`);
  });
});

// Event listener for commenting button
document.querySelectorAll(".comment-btn").forEach((button) => {
  button.addEventListener("click", (event) => {
    const recipeTitle =
      event.target.parentElement.querySelector("h3").textContent;
    // Here you can implement the logic to handle commenting
    alert(`You clicked Comment for ${recipeTitle}`);
  });
});

// Event listener for sharing button
document.querySelectorAll(".share-btn").forEach((button) => {
  button.addEventListener("click", (event) => {
    const recipeTitle =
      event.target.parentElement.querySelector("h3").textContent;
    // Here you can implement the logic to handle sharing
    alert(`You clicked Share for ${recipeTitle}`);
  });
});

// Event listener for login button
// Event listener for login button
document.getElementById("login").addEventListener("click", () => {
  alert("Login button clicked. Functionality not implemented.");
});
